﻿unsigned char cheat[] =
{
	NULL
	// Your signed DLL
};
